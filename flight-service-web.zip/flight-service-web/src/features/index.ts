export * from './Home/HomeView';
export * from './Service/ServiceListView';
export * from './People/PeopleListView';
//export * from './Confirmationlists/ConfirmationlistListView';