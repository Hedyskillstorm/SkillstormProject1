import { AxiosResponse } from "axios";
import React from "react";
import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import Passenger from "../../models/Passenger";
import APIService from "../../services/apiService";


type PeopleListViewProps = {

}
type PeopleListViewState = { people: Passenger[] }

export class PeopleListView extends React.Component<PeopleListViewProps, PeopleListViewState> {
    constructor(props: PeopleListViewProps) {
        super(props);
        this.state = {
            people: []
        }
    }

    componentDidMount() {
        APIService.getPeople()
            .then((response) => {
                this.setState({
                    people: response.data
                });
            })
            .catch((err: Error) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <div className="App container">
                <div className="jumbotron">
                    <h2>Passengers</h2>
                </div>
                <table className="table table-striped table-bordered table-hover table-highlight">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Job</th>
                            <th>Email</th>
                            <th>Birthday</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.people.map((passenger: Passenger) => (
                            <React.Fragment key={passenger.Id}>
                                <tr id={"passenger-" + passenger.Id}>
                                    <td>{passenger.Id}</td>
                                    <td>{passenger.FirstName}</td>
                                    <td>{passenger.LastName}</td>
                                    <td>{passenger.Job}</td>
                                    <td>{passenger.Email}</td>
                                    <td>{passenger.Birthday}</td>
                                    <td>
                                        <Link to={'${passenger.Id}'} className="btnbtn-primary">
                                            Edit
                                        </Link>

                                    </td>
                                </tr>
                            </React.Fragment>
                        ))};
                    </tbody>
                </table>
            </div>
        );
    }
}

export default PeopleListView;