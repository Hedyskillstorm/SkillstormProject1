import React from "react";
import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import Confirmationlist from "../../models/Confirmationlist";

type ConfirmationlistTableDisplayProps = {
    confirmationlists: Confirmationlist[] | null;
    title: string;
}

class ConfirmationlistTableDisplay extends React.Component<ConfirmationlistTableDisplayProps> {
    render() {
        if (this.props.confirmationlists === null || this.props.title === null) {
            return ('');
        } else {
            return (
                <>
                    <dt className="col-sm-2">{this.props.title}</dt>
                    <dd className="col-sm-10">
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Total Tracks</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.props.confirmationlists.map((clist: Confirmationlist) => (
                                    <React.Fragment key={clist.Id}>
                                        <tr>
                                            <td>{clist.Id}</td>
                                            <td>{clist.FlightId}</td>
                                            <td>{clist.PassengerId}</td>

                                            <td><Link to={`confirmationlist/${clist.Id}`} className="btn btn-primary">Details</Link></td>
                                        </tr>
                                    </React.Fragment>
                                ))};
                            </tbody>
                        </Table>
                    </dd>
                </>
            );
        }
    }
}
export default ConfirmationlistTableDisplay;