import React from 'react';
import { Link } from 'react-router-dom';
import Flight from '../../models/flight';

type ReservedFlightProps = {
    flight: Flight | null;
}

class ReservedFlight extends React.Component<ReservedFlightProps> {
    render(): React.ReactNode {
        let fid = this.props.flight?.Id ?? 0;
        if (this.props.flight == null || fid === 0) {
            return ('');
        } else {
            console.log(this.props.flight)
            return (
                <>
                    <dt className="col-sm-2">Reserved Flight:</dt>
                    <dd className="col-sm-10">
                        <Link
                            to={`/music/${this.props.flight.Id}`}><b>{this.props.flight.DepartureDate}</b> - {this.props.flight.ArrivalDate} off the Flight {this.props.flight.Id}</Link>
                    </dd>
                </>
            );
        }
    }
}

export default ReservedFlight;