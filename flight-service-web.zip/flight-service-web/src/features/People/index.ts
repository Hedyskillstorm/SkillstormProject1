export * from './PeopleListView';
export * from './People';
//export * from './ReservedFlight';
export * from './PersonDetailsView';
// export { peopleSlice } from './peopleSlice'