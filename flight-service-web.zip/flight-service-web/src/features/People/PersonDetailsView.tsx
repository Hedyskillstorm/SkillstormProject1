import { AxiosResponse } from 'axios';
import React, { ChangeEvent, MouseEvent } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import withRouter, { RoutedProps } from '../../Components/utility/routed-props';
import PassengerToUpdate from '../../models/Passenger';
import confirmationlist from '../../models/Confirmationlist';
import Passenger from '../../models/Passenger';
import Flight from '../../models/flight';
import APIService from '../../services/apiService';
import FavoriteSong from './ReservedFlight';
import ConfirmationlistTableDisplay from './ConfirmationlistTableDisplay';

interface PeopleDetailsParams {
    passengerId: string;
}

type PassengerDetailsViewProps = RoutedProps<PeopleDetailsParams>;

type PassengerDetailsViewState = {
    Id: number;
    FirstName: string;
    LastName: string;
    Job: string;
    Email: string;
    Birthday: string;
    Passenger: [];
    showEditForm: boolean;
};

export class PassengerDetailsView extends React.Component<PassengerDetailsViewProps, PassengerDetailsViewState> {
    constructor(props: PassengerDetailsViewProps) {
        super(props);
        this.state = {
            Id: this.props.params.passengerId as unknown as number,
            FirstName: '',
            LastName: '',
            Birthday: '',
            Email: '',
            Job: '',
            Passenger: [],
            showEditForm: false
        };
    }

    componentDidMount() {
        APIService.getPerson(this.props.params.passengerId as unknown as number)
            .then((response: AxiosResponse<Passenger>) => {
                let s = response.data;
                this.setState({
                    Id: s.Id,
                    FirstName: s.FirstName,
                    LastName: s.LastName,
                    Birthday: s.Birthday,
                    Email: s.Email,
                    Job: s.Job,



                });
            })
    }

    handleEditBtnClick = (event: MouseEvent<HTMLButtonElement>) => {
        this.setState({
            showEditForm: true
        });
    }

    handleFirstNameChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            FirstName: event.target.value
        });
    }

    handleLastNameChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            LastName: event.target.value
        });
    }

    handleBirthdayChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            Birthday: event.target.value
        });
    }

    handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        let passengerChanged: PassengerToUpdate = {
            Id: this.state.Id,
            FirstName: this.state.FirstName,
            LastName: this.state.LastName,
            Birthday: this.state.Birthday,
            Email: this.state.Email,
            Job: this.state.Job,
        };
        this.handleUpdateModel(passengerChanged);
        this.handleCloseClick();
    }

    handleSaveChangesClick = (event: MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        let passengerChanged: PassengerToUpdate = {
            Id: this.state.Id,
            FirstName: this.state.FirstName,
            LastName: this.state.LastName,
            Birthday: this.state.Birthday,
            Email: this.state.Email,
            Job: this.state.Job,
        };
        this.handleUpdateModel(passengerChanged);
        this.handleCloseClick();
    }

    handleCloseClick = () => {
        this.setState({
            showEditForm: false
        });
    }

    handleUpdateModel = (passenger: PassengerToUpdate) => {
        APIService.updatePeople(passenger)
            .then((response: AxiosResponse<Passenger>) => {
                let p = response.data;
                this.setState({
                    Id: p.Id,
                    FirstName: p.FirstName,
                    LastName: p.LastName,
                    Birthday: p.Birthday,
                    Email: p.Email,
                    Job: p.Job
                });
            }).catch((err: any) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <>
                <div className="App container">
                    <div className="jumbotron">
                        <h4>Passenger Details</h4>
                    </div>
                    <hr />
                    <dl className="row">
                        <dt className="col-sm-2">Id:</dt><dd className="col-sm-10">{this.state.Id}</dd>
                        <dt className="col-sm-2">First Name:</dt><dd className="col-sm-10">{this.state.FirstName}</dd>
                        <dt className="col-sm-2">Last Name:</dt><dd className="col-sm-10">{this.state.LastName}</dd>
                        <dt className="col-sm-2">Birthday:</dt><dd className="col-sm-10">{this.state.Birthday}</dd>


                    </dl>
                    <div>
                        <Link to="/music">
                            <Button className="btn btn-danger">&lt; Back</Button>
                        </Link>
                        <Button className="btn btn-primary" onClick={this.handleEditBtnClick}>Edit</Button>
                    </div>
                    <hr />
                    <div>

                    </div>
                </div>
                <Modal show={this.state.showEditForm} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">Edit Passenger</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form onSubmit={this.handleFormSubmit}>
                            <Form.Group className="mb-3" controlId="passengerId">
                                <Form.Label>Id</Form.Label>
                                <Form.Control value={this.state.Id} disabled />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="firstName">
                                <Form.Label>First Name:</Form.Label>
                                <Form.Control type="text" value={this.state.FirstName} onChange={this.handleFirstNameChange} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="lastName">
                                <Form.Label>Last Name:</Form.Label>
                                <Form.Control type="text" value={this.state.LastName} onChange={this.handleLastNameChange} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="birthday">
                                <Form.Label>Birthday</Form.Label>
                                <Form.Control type="text" value={this.state.Birthday} onChange={this.handleBirthdayChange} />
                            </Form.Group>
                        </Form>


                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant='secondary' onClick={this.handleCloseClick}>Close</Button>
                        <Button variant='primary' onClick={this.handleSaveChangesClick}>Save</Button>
                    </Modal.Footer>

                </Modal>
            </>
        );
    }
}

export default withRouter(PassengerDetailsView);