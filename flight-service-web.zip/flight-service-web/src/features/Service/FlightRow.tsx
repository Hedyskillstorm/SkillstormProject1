import React, { Component } from "react";
import Flight from "../../models/flight";

type FlightRowProps = {
    flight: Flight;
}

type FlightRowState = {

}

class FlightRow extends Component<FlightRowProps, FlightRowState> {
    render() {
        const flight = this.props.flight;
        let flightId = `flight${flight.Id}`;
        return (
            <React.Fragment key={flight.Id}>
                <tr id={flightId}>

                    <td>{flight.DepartureDate}</td>
                    <td>{flight.ArrivalDate}</td>
                    <td>{flight.DepartureAirport}</td>
                    <td>{flight.ArrivalAirport}</td>
                    <td>{flight.LimitNum}</td>
                </tr>
            </React.Fragment>
        );
    }
}

export default FlightRow;