import React from "react";

const FlightTableColumns = (props: any): JSX.Element => {

    return (
        <>
            <tr>
                <th>FlightNum</th>
                <th>DepartureDate</th>
                <th>ArrivalDate</th>
                <th>DepartureAirport</th>
                <th>ArrivalAirport</th>
                <th>LimitNum</th>
            </tr>
        </>
    );
};

export default FlightTableColumns;