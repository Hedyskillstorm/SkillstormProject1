import React from 'react';
import { Outlet, Route, Routes } from 'react-router-dom';
import ServiceDetailsView from './ServiceDetailsView';
import ServiceListView from './ServiceListView';

type ServiceProps = {};
type ServiceState = {};

export class Service extends React.Component<ServiceProps, ServiceState> {
    constructor(props: ServiceProps) {
        super(props);
        this.state = {

        };
    }
    componentDidMount() {

    }
    render(): React.ReactNode {
        return (
            <>
                <Routes>
                    <Route index element={<ServiceListView />} />
                    <Route path=':flightId' element={<ServiceDetailsView />} />
                </Routes>

                <Outlet />
            </>
        );
    }
}