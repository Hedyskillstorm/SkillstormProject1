import React, { Component } from "react";
import Flight from "../../models/flight";
//import FlightRow from "./FlightRow";
import Columns from "./FlightTableColumns";

type Props = {
    filterText: string;
    flights: Flight[];
}

type State = {

}

class FlightTable extends Component<Props, State> {
    render() {
        return (
            <table className="table table-bordered table-striped table-hover table-highlight">
                <thead>
                    <Columns />
                </thead>
                <tbody>
                    {this.props.flights.map((flight: Flight) => (
                        // <SongRow flight={flight} key={flight.Id} />
                        <React.Fragment key={flight.Id}>
                            <tr id={"flight-" + flight.Id}>
                                <td>{flight.DepartureDate}</td>
                                <td>{flight.ArrivalDate}</td>
                                <td>{flight.DepartureAirport}</td>
                                <td>{flight.ArrivalAirport}</td>
                                <td>{flight.LimitNum}</td>
                            </tr>
                        </React.Fragment>
                    ))};
                </tbody>
            </table>
        );
    };
}

export default FlightTable;