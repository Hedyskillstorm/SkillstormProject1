import { AxiosResponse } from 'axios';
import React, { ChangeEvent, MouseEvent } from 'react';
import { Button, Card, Form, ListGroup, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import withRouter, { RoutedProps } from '../../Components/utility/routed-props';
import Flight from "../../models/flight";
import FlightToUpdate from "../../models/flight";
import APIService from '../../services/apiService';

interface ServiceDetailsParams {
    flightId: number;
}

type ServiceDetailsViewProps = RoutedProps<ServiceDetailsParams>;

type ServiceDetailsViewState = {
    Id: number,
    DepartureDate: any,
    ArrivalDate: any,
    DepartureTime: any,
    ArrivalTime: any,
    DepartureAirport: string,
    ArrivalAirport: string,
    LimitNum: string,
    showEditForm: boolean;

};

export class ServiceDetailsView extends React.Component<ServiceDetailsViewProps, ServiceDetailsViewState> {
    constructor(props: ServiceDetailsViewProps) {
        super(props);
        this.state = {
            Id: this.props.params.flightId as unknown as number,
            DepartureDate: '',
            ArrivalDate: '',
            DepartureTime: '',
            ArrivalTime: '',
            DepartureAirport: '',
            ArrivalAirport: '',
            LimitNum: '',
            showEditForm: false
        };
    }
    componentDidMount() {
        APIService.getFlight(this.props.params.flightId as unknown as number)
            .then((response: AxiosResponse<Flight>) => {
                let f = response.data;
                this.setState({
                    Id: f.Id,
                    DepartureDate: f.DepartureDate,
                    ArrivalDate: f.ArrivalDate,
                    DepartureAirport: f.DepartureAirport,
                    ArrivalAirport: f.ArrivalAirport,
                    LimitNum: f.LimitNum,
                    showEditForm: false


                });
            })
    }

    handleEditBtnClick = (event: MouseEvent<HTMLButtonElement>) => {
        this.setState({
            showEditForm: true
        });
    }



    handleDepartureDateChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            DepartureDate: event.target.value
        });
    }

    handleArrivalDateChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            ArrivalDate: event.target.value
        });
    }

    handleDepartureAirportChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            DepartureAirport: event.target.value
        });
    }

    handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        let FlightChanged: FlightToUpdate = {
            Id: this.state.Id,

            DepartureDate: this.state.DepartureDate,
            ArrivalDate: this.state.ArrivalDate,
            DepartureAirport: this.state.DepartureAirport,
            ArrivalAirport: this.state.ArrivalAirport,
            LimitNum: this.state.LimitNum,
            DepartureTime: this.state.DepartureTime,
            ArrivalTime: this.state.ArrivalTime,
            Passengers: []
        };
        this.handleUpdateModel(FlightChanged);
        this.handleCloseClick();
    }

    handleSaveChangesClick = (event: MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        let flightChanged: FlightToUpdate = {
            Id: this.state.Id,
            DepartureDate: this.state.DepartureDate,
            ArrivalDate: this.state.ArrivalDate,
            DepartureTime: this.state.DepartureTime,
            ArrivalTime: this.state.DepartureTime,
            DepartureAirport: this.state.DepartureAirport,
            ArrivalAirport: this.state.ArrivalAirport,
            LimitNum: this.state.LimitNum,
            Passengers: []
        };
        this.handleUpdateModel(flightChanged);
        this.handleCloseClick();
    }

    handleCloseClick = () => {
        this.setState({
            showEditForm: false
        });
    }

    handleUpdateModel = (flight: FlightToUpdate) => {
        APIService.updateFlight(flight)
            .then((response: AxiosResponse<Flight>) => {
                let f = response.data;
                this.setState({
                    Id: f.Id,

                    DepartureDate: f.DepartureDate,
                    ArrivalDate: f.ArrivalDate,
                    DepartureAirport: f.DepartureAirport,
                    ArrivalAirport: f.ArrivalAirport,
                    LimitNum: f.LimitNum

                });
            }).catch((err) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <>
                <div className="App container">
                    <Card>
                        <Card.Title>
                            <h4>Flight Details</h4>
                        </Card.Title>
                        <Card.Body>
                            <ListGroup>
                                <ListGroup.Item>Id: {this.state.Id}</ListGroup.Item>

                                <ListGroup.Item>DepartureDate: {this.state.DepartureDate}</ListGroup.Item>
                                <ListGroup.Item>ArrivalDate: {this.state.ArrivalDate}</ListGroup.Item>
                                <ListGroup.Item>DepartureAirport: {this.state.DepartureAirport}</ListGroup.Item>
                                <ListGroup.Item>ArrivalAirport: {this.state.ArrivalAirport}</ListGroup.Item>
                                <ListGroup.Item>LimitNum: {this.state.LimitNum}</ListGroup.Item>
                            </ListGroup>
                        </Card.Body>
                        <div >



                            <Link to="/service">
                                <Button className="btn btn-danger">&lt; Back</Button>
                            </Link>
                            &nbsp;&nbsp;||&nbsp;&nbsp;
                            <Button className="btn btn-primary" onClick={this.handleEditBtnClick}>Edit</Button>
                        </div>
                    </Card>
                </div>
                <Modal show={this.state.showEditForm} size="lg" aria-labelledby="contained-modal-title-vcenter">
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">Edit Flight</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form onSubmit={this.handleFormSubmit}>
                            <Form.Group className="mb-3" controlId="flightId">
                                <Form.Label>Id</Form.Label>
                                <Form.Control value={this.state.Id} disabled />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="flightDepartureDate">
                                <Form.Label>DepartureDate</Form.Label>
                                <Form.Control type="text" value={this.state.DepartureDate} onChange={this.handleDepartureDateChange} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="flightArrivalDate">
                                <Form.Label>ArrivalDat</Form.Label>
                                <Form.Control type="text" value={this.state.ArrivalDate} onChange={this.handleArrivalDateChange} />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="flightDepartureAirport">
                                <Form.Label>DepartureDate</Form.Label>
                                <Form.Control type="text" value={this.state.DepartureAirport} onChange={this.handleDepartureAirportChange} />
                            </Form.Group>


                        </Form>


                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant='secondary' onClick={this.handleCloseClick}>Close</Button>

                        <Button variant='primary' onClick={this.handleSaveChangesClick}>Save</Button>
                    </Modal.Footer>

                </Modal>
            </>
        );
    }
}

export default withRouter(ServiceDetailsView);