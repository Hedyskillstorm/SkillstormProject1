import { createAction } from '@reduxjs/toolkit';
import Song from '../../models/flight';


export const createSrvice = createAction('service/add', function prepare(DepartureDate: string, FlightNum: Number, ArrivalDate: string, DepartureAirport: string, ArrivalAirport: string, LimitNum: number) {
    return {
        payload: {
            FlightNum: FlightNum,
            DepartureDate: DepartureDate,
            ArrivalDate: ArrivalDate,
            DepartureAirport: DepartureAirport,
            ArrivalAirport: ArrivalAirport,
            LimitNum: LimitNum
        }
    }
});
export const getService = createAction('service/all');
export const getSong = createAction('service/get', function prepare(id: number) {
    return {
        payload: {
            Id: id
        }
    }
});
export const updateService = createAction('service/update', function prepare(id: number, flight: Song) {
    return {
        payload: {
            Id: id,
            Song: flight
        }
    }
});
export const deleteService = createAction('service/delete', function prepare(id: number) {
    return {
        payload: {
            Id: id
        }
    }
});
export const deleteAllService = createAction('service/delete_all');

// export const CREATE_PLAYLIST = "CREATE_PLAYLIST";
// export const GET_PLAYLISTS = "GET_PLAYLISTS";
// export const GET_PLAYLIST = "GET_PLAYLIST";
// export const UPDATE_PLAYLIST = "UPDATE_PLAYLIST";
// export const DELETE_PLAYLIST = "DELETE_PLAYLIST";
// export const DELETE_ALL_PLAYLISTS = "DELETE_ALL_PLAYLISTS";