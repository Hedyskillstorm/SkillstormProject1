import { AxiosResponse } from "axios";
import React from "react";
import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import Flight from "../../models/flight";
import APIService from "../../services/apiService";

type ServiceListViewProps = {

}

type ServiceListViewState = {
    flights: Flight[];

}

class ServiceListView extends React.Component<ServiceListViewProps, ServiceListViewState> {
    constructor(props: ServiceListViewProps) {
        super(props);
        this.state = {
            flights: []
        }
    }

    componentDidMount() {
        APIService.getFlights()
            .then((response: AxiosResponse<Flight[]>) => {
                this.setState({
                    flights: response.data
                });
            })
            .catch((err: Error) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <div className="App container">
                <div className="jumbotron">
                    <h2>Flights List</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>FlightNum</th>
                            <th>DepartureDate</th>
                            <th>ArrivalDate</th>
                            <th>DepartureAirport</th>
                            <th>ArrivalAirport</th>
                            <th>LimitNum</th>

                            <th></th>
                        </tr>

                    </thead>
                    <tbody>
                        {this.state.flights.map((flight: Flight) => (
                            <React.Fragment key={flight.Id}>
                                <tr id={"flight-" + flight.Id}>

                                    <td>{flight.DepartureDate}</td>
                                    <td>{flight.ArrivalDate}</td>
                                    <td>{flight.DepartureAirport}</td>
                                    <td>{flight.ArrivalAirport}</td>
                                    <td>{flight.LimitNum}</td>
                                    <td>

                                        <Link className="btn btn-primary" to={`${flight.Id}`}>Details</Link>
                                    </td>
                                </tr>
                            </React.Fragment>
                        ))};
                    </tbody>
                </table>
            </div>

        );
    }
}


export default ServiceListView;