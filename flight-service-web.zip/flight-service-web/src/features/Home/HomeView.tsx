import React from "react";
import Flight from "../../models/flight";


class HomeView extends React.Component {
    render(): React.ReactNode {
        return (
            <div className="App container">
                <div className="jumbotron">
                    <h2>Welcome to Flight Services App</h2>
                </div>
            </div>
        );
    };
};

export default HomeView;