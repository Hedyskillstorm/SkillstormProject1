import { createAction } from '@reduxjs/toolkit';
import Confirmationlist from '../../models/Confirmationlist';


export const createConfirmationlist = createAction('confirmationlists/add', function prepare(fName: string, lName: string, bday: string) {
    return {
        payload: {
            FirstName: fName,
            LastName: lName,
            Birthday: bday
        }
    }
});
export const getConfirmationlists = createAction('confirmationlists/all');
export const getConfirmationlist = createAction('confirmationlists/get', function prepare(id: number) {
    return {
        payload: {
            Id: id
        }
    }
});
export const updateConfirmationlist = createAction('confirmationlists/update', function prepare(id: number, plist: Confirmationlist) {
    return {
        payload: {
            Id: id,
            Confirmationlist: plist
        }
    }
});
export const deleteConfirmationlist = createAction('confirmationlists/delete', function prepare(id: number) {
    return {
        payload: {
            Id: id
        }
    }
});
export const deleteConfirmationlists = createAction('confirmationlists/delete_all');

// export const CREATE_PLAYLIST = "CREATE_PLAYLIST";
// export const GET_PLAYLISTS = "GET_PLAYLISTS";
// export const GET_PLAYLIST = "GET_PLAYLIST";
// export const UPDATE_PLAYLIST = "UPDATE_PLAYLIST";
// export const DELETE_PLAYLIST = "DELETE_PLAYLIST";
// export const DELETE_ALL_PLAYLISTS = "DELETE_ALL_PLAYLISTS";