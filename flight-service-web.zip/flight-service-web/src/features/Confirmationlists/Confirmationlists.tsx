import React from 'react';
import { Outlet, Route, Routes } from 'react-router-dom';
import ConfirmationlistDetailsView from './ConfirmationlistDetailsView';
import ConfirmationlistListView from './ConfirmationlistListView';

type ConfirmationlistProps = {};
type ConfirmationlistState = {};

export class Confirmationlist extends React.Component<ConfirmationlistProps, ConfirmationlistState> {
    constructor(props: ConfirmationlistProps) {
        super(props);
        this.state = {

        };
    }
    componentDidMount() {

    }
    render(): React.ReactNode {
        return (
            <>
                <Routes>
                    <Route index element={<ConfirmationlistListView />} />
                    <Route path=':confirmationlistId' element={<ConfirmationlistDetailsView />} />
                </Routes>

                <Outlet />
            </>
        );
    }
}

export default Confirmationlist;