import React from 'react';
import { Link } from 'react-router-dom';
import Passenger from '../../models/Passenger';

type ConfirmationlistOwnerProps = {
    owner: Passenger;
}

export class ConfirmationlistOwner extends React.Component<ConfirmationlistOwnerProps> {
    render(): React.ReactNode {
        if (this.props.owner === null) {
            return (
                <>
                    <td></td>
                </>
            );
        } else {
            return (
                <>
                    <td><Link to={`{passenger/${this.props.owner.Id}`}>{this.props.owner.FirstName} {this.props.owner.LastName}</Link></td>
                </>
            );
        }
    }
}