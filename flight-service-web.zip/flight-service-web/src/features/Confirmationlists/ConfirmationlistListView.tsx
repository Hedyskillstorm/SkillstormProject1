import { AxiosResponse } from "axios";
import React from "react";
import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import Confirmationlist from "../../models/Confirmationlist";
import APIService from "../../services/apiService";
import { ConfirmationlistOwner } from "./ConfirmationlistOwner";

type ConfirmationlistListViewProps = {

}

type ConfirmationlistViewState = {
    confirmationlists: Confirmationlist[];

}

class ConfirmationlistListView extends React.Component<ConfirmationlistListViewProps, ConfirmationlistViewState> {
    constructor(props: ConfirmationlistListViewProps) {
        super(props);
        this.state = {
            confirmationlists: []
        }
    }

    componentDidMount() {
        APIService.getConfirmationlists()
            .then((response) => {
                this.setState({
                    confirmationlists: response.data
                });
            })
            .catch((err: Error) => {
                console.log(err);
            });
    }


    render(): React.ReactNode {
        return (
            <div className="App container">
                <div className="jumbotron">
                    <h2>Confirmationlists</h2>
                </div>
                <table className="table table-striped table-bordered table-hover table-highlight">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>FlightId</th>
                            <th>PassengerId</th>
                            <th></th>


                        </tr>
                    </thead>
                    <tbody>
                        {this.state.confirmationlists.map((confirmationlist: Confirmationlist) => (
                            <React.Fragment key={confirmationlist.Id}>
                                <tr id={"flight-" + confirmationlist.Id}>
                                    <td>{confirmationlist.Id}</td>
                                    <td>{confirmationlist.FlightId}</td>
                                    <td>{confirmationlist.PassengerId}</td>
                                    <td>
                                        <Link to={'${confirmationlist.Id}'} className="btn btn-primary">

                                            Details
                                        </Link>

                                    </td>
                                </tr>
                            </React.Fragment>
                        ))};
                    </tbody>
                </table>
            </div>
        );
    }
}

export default ConfirmationlistListView;