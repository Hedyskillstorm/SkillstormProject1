import { AxiosResponse } from 'axios';
import React, { ChangeEvent } from 'react';
import { Form, Button, Container } from 'react-bootstrap';
import withRouter, { RoutedProps } from '../../Components/utility/routed-props';
import Confirmationlist, { ConfirmationlistToAdd } from '../../models/Confirmationlist';
import APIService from '../../services/apiService';

type NewConfirmationlistViewProps = RoutedProps;
type NewConfirmationlistViewState = {

    FlightId: any;
    PassengerId: any;

    showEditForm: boolean;
}

export class NewConfirmationlistView extends React.Component<NewConfirmationlistViewProps, NewConfirmationlistViewState> {
    constructor(props: NewConfirmationlistViewProps) {
        super(props);
        this.state = {
            FlightId: '',
            PassengerId: '',
            showEditForm: false,


        }
    }

    handleTitleChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            FlightId: event.target.value
        });
    }

    handleDescriptionChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({
            PassengerId: event.target.value
        });
    }

    handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        let confirmationlistChanged: ConfirmationlistToAdd = {
            FlightId: this.state.FlightId,
            PassengerId: this.state.PassengerId
        };
        this.handleUpdateModel(confirmationlistChanged);
        this.handleCloseClick();
    }

    handleSaveChangesClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        let confirmationlistChanged: ConfirmationlistToAdd = {
            FlightId: this.state.FlightId,
            PassengerId: this.state.PassengerId
        };
        this.handleUpdateModel(confirmationlistChanged);
        this.handleCloseClick();
    }

    handleCloseClick = () => {
        this.props.history.goBack();
    }

    handleUpdateModel = (confirmationlist: ConfirmationlistToAdd) => {
        APIService.createConfirmationlist(confirmationlist)
            .then((response: AxiosResponse<Confirmationlist>) => {
                let p = response.data;
                console.log(`Successfully added ${p}`);
            })
            .catch((err) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <>
                <div className='appContainer'>
                    <div className="jumbotron">
                        <h2>Add New Confirmationlist</h2>
                    </div>
                    <Container>
                        <Form onSubmit={this.handleFormSubmit}>
                            <Form.Group className="mb-3" controlId="confirmationlistId">
                                <Form.Label>Id</Form.Label>
                                <Form.Control placeholder="Disabled input" disabled />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="PassengerId">
                                <Form.Label>FlightId</Form.Label>
                                <Form.Control type="text" value={this.state.FlightId} onChange={this.handleTitleChange} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="FlightId">
                                <Form.Label>Description</Form.Label>
                                <Form.Control type="text" value={this.state.PassengerId} onChange={this.handleDescriptionChange} />
                            </Form.Group>
                            <Form.Group>
                                <Button variant='secondary' onClick={this.handleCloseClick}>Close</Button>
                                <Button variant='primary' onClick={this.handleSaveChangesClick}>Save</Button>
                            </Form.Group>
                        </Form>
                    </Container>
                </div>
            </>
        );
    }
}

export default withRouter(NewConfirmationlistView);