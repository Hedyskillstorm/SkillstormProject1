import { AxiosResponse } from 'axios';
import React, { ChangeEvent, MouseEvent } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import withRouter, { RoutedProps } from '../../Components/utility/routed-props';
import Confirmationlist from '../../models/Confirmationlist'
import { ConfirmationlistToUpdate } from '../../models/Confirmationlist';
import APIService from '../../services/apiService';

interface ConfirmationlistDetailsParams {
    confirmationlistId: string;
}

type ConfirmationlistDetailsViewProps = RoutedProps<ConfirmationlistDetailsParams>;

type ConfirmationlistDetailsViewState = {
    Id: number;
    FlightId: any;
    PassengerId: any;

    showEditForm: boolean;


};

export class ConfirmationlistDetailsView extends React.Component<ConfirmationlistDetailsViewProps, ConfirmationlistDetailsViewState> {

    constructor(props: ConfirmationlistDetailsViewProps) {
        super(props);
        this.state = {
            Id: this.props.params.confirmationlistId as unknown as number,
            FlightId: '',
            PassengerId: '',
            showEditForm: false
        };
    }
    componentDidMount() {
        APIService.getConfirmationlist(this.props.params.confirmationlistId as unknown as number)
            .then((response: AxiosResponse<Confirmationlist>) => {
                let p = response.data;
                this.setState({
                    Id: p.Id,
                });
            })
    }

    handleEditBtnClick = (event: MouseEvent<HTMLButtonElement>) => {
        this.setState({
            showEditForm: true
        });
    }



    handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        let confirmationlistChanged: ConfirmationlistToUpdate = {
            Id: this.state.Id,
            FlightId: this.state.FlightId,
            PassengerId: this.state.PassengerId,
            //showEditForm: this.state.boolean

        };
        this.handleUpdateModel(confirmationlistChanged);
        this.handleCloseClick();
    }

    handleSaveChangesClick = (event: MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        let confirmationlistChanged: ConfirmationlistToUpdate = {
            Id: this.state.Id,
            FlightId: this.state.FlightId,
            PassengerId: this.state.PassengerId,
            //showEditForm: this.state.boolean

        };
        this.handleUpdateModel(confirmationlistChanged);
        this.handleCloseClick();
    }

    handleCloseClick = () => {
        this.setState({
            showEditForm: false
        });
    }

    handleUpdateModel = (confirmationlist: ConfirmationlistToUpdate) => {
        APIService.updateConfirmationlist(confirmationlist)
            .then((response: AxiosResponse<Confirmationlist>) => {
                let p = response.data;
                this.setState({
                    Id: p.Id,

                });
            }).catch((err) => {
                console.log(err);
            });
    }

    render(): React.ReactNode {
        return (
            <>
                <div className="App container">
                    <div className="jumbotron">
                        <h4>Confirmationlist Details</h4>
                    </div>
                    <hr />
                    <dl className="row">
                        <dt className="col-sm-2">Id:</dt><dd className="col-sm-10">{this.state.Id}</dd>
                        <dt className="col-sm-2">FlightId:</dt><dd className="col-sm-10">{this.state.FlightId}</dd>
                        <dt className="col-sm-2">PassengerId:</dt><dd className="col-sm-10">{this.state.PassengerId}</dd>


                    </dl>
                    <div>
                        <Link to="/service">
                            <Button className="btn btn-danger">&lt; Back</Button>
                        </Link>
                        <Button className="btn btn-primary" onClick={this.handleEditBtnClick}>Edit</Button>
                    </div>
                </div>
                <Modal show={this.state.showEditForm} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">Edit Confirmationlist</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form onSubmit={this.handleFormSubmit}>
                            <Form.Group className="mb-3" controlId="confirmationlistId">
                                <Form.Label>Id</Form.Label>
                                <Form.Control value={this.state.Id} disabled />
                            </Form.Group>


                        </Form>


                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant='secondary' onClick={this.handleCloseClick}>Close</Button>
                        <Button variant='primary' onClick={this.handleSaveChangesClick}>Save</Button>
                    </Modal.Footer>

                </Modal>
            </>
        );
    }
}

export default withRouter(ConfirmationlistDetailsView);