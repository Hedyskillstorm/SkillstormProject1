import Flight from '../models/flight';
import axios from "axios";
import Passenger, { PassengerToAdd } from "../models/Passenger"
import Confirmationlist, { ConfirmationlistToAdd } from '../models/Confirmationlist';


const http = axios.create({
    baseURL: "https://localhost:7269",
    headers: {
        'Content-Type': 'application/json'
    }
});

const getFlights = () => {
    return http.get<Array<Flight>>("/api/Service");
};

const getFlight = (id: number) => {
    return http.get<Flight>(`api/Service/${id}`);
}

const createFlight = (Flight: Flight) => {
    return http.post<Flight>("api/Service", Flight);
};

const updateFlight = (Flight: Flight) => {
    return http.put<Flight>(`api/Service/${Flight.Id}`, Flight);
};

const deleteFlight = (id: number) => {
    return http.delete<Flight>(`api/Service/${id}`);
};

const getPeople = () => {
    return http.get<Array<Passenger>>("/api/People");
};

const getPerson = (id: number) => {
    return http.get<Passenger>(`/api/People/${id}`);
}

const createPeople = (Passenger: PassengerToAdd) => {
    return http.post<Passenger>("/api/People", Passenger);
};

const updatePeople = (Passenger: Passenger) => {
    return http.put<Passenger>(`/api/People/${Passenger.Id}`, Passenger);
};

const deletePeople = (id: number) => {
    return http.delete(`/api/People/${id}`);
};

const getConfirmationlists = () => {
    return http.get<Array<Confirmationlist>>("/api/ConfirmationLists");
};

const getConfirmationlist = (id: number) => {
    return http.get<Confirmationlist>(`/api/ConfirmationLists/${id}`);
}

const createConfirmationlist = (conf: ConfirmationlistToAdd) => {
    return http.post<Confirmationlist>("/api/ConfirmationLists", conf);
};

const updateConfirmationlist = (Confirmationlist: Confirmationlist) => {
    return http.put<Confirmationlist>(`/api/ConfirmationLists/${Confirmationlist.Id}`, Confirmationlist);
};

const deleteConfirmationlist = (id: number) => {
    return http.delete(`/api/ConfirmationLists/${id}`);
};

const APIService = {
    getFlights,
    getFlight,
    createFlight,
    updateFlight,
    deleteFlight,
    getPeople,
    getPerson,
    createPeople,
    updatePeople,
    deletePeople,
    getConfirmationlist,
    getConfirmationlists,
    createConfirmationlist,
    updateConfirmationlist,
    deleteConfirmationlist,





};

export default APIService;