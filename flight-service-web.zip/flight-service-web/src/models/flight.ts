import Confirmationlist from "./Confirmationlist";
import Passenger from "./Passenger";

interface Flight {
    Id: number;
    DepartureDate: any;
    ArrivalDate: any;
    DepartureTime: any;
    ArrivalTime: any;
    DepartureAirport: string;
    ArrivalAirport: string;
    LimitNum: any;
    Passengers: Passenger[];

}

export interface FlightToAdd {
    DepartureDate: any;
    ArrivalDate: any;
    DepartureTime: any;
    ArrivalTime: any;
    DepartureAirport: string;
    ArrivalAirport: string;
    LimitNum: any;
    Passengers: Passenger[];
}

export interface FlightToUpdate {
    Id: number;
    DepartureDate: any;
    ArrivalDate: any;
    DepartureTime: any;
    ArrivalTime: any;
    DepartureAirport: string;
    ArrivalAirport: string;
    LimitNum: any;
    Passengers: Passenger[];
}

export default Flight;