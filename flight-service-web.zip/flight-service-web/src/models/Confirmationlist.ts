import Passenger from "./Passenger";
import Flight from "./flight";

interface Confirmationlist {
    Id: number;
    FlightId: number;
    PassengerId: number;
    //Owner: Passenger;


}

export interface ConfirmationlistToAdd {

    FlightId: number;
    PassengerId: number;
}


export interface ConfirmationlistToUpdate {
    Id: number;
    FlightId: any;
    PassengerId: any;
    //Owner: Passenger;

}

export default Confirmationlist;