import Confirmationlist from "./Confirmationlist";
import Flight from "./flight";

interface Passenger {
    Id: number;
    FirstName: string;
    LastName: string;
    Job: string;
    Email: string;
    Birthday: string;
}

export interface PassengerToAdd {
    FirstName: string;
    LastName: string;
    Job: string;
    Email: string;
    Birthday: string;
}

export interface PassengerToUpdate {
    Id: number;
    FirstName: string;
    LastName: string;
    Job: string;
    Email: string;
    Birthday: string;

}

export default Passenger;