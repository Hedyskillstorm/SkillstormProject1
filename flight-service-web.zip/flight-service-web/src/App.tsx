

import React from "react";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import NavigationBar from "./Components/NavigationBar";
import HomeView from "./features/Home/HomeView";
import { Service } from "./features/Service";
import { People } from "./features/People";
import Confirmationlist from "./features/Confirmationlists/Confirmationlists";

type AppProps = {

};

type AppState = {};

class App extends React.Component<AppProps, AppState> {
  render() {
    return (
      <main>
        <NavigationBar />
        <Routes>
          <Route path="/" element={<HomeView />} />
          <Route path="service/*" element={<Service />} />
          <Route path="people/*" element={<People />} />
          <Route path="confirmationlist/*" element={<Confirmationlist />} />
        </Routes>
      </main>
    );
  }
}

export default App;
